/* 
 * File:   rational.cpp
 * Author: vanessa
 *
 * Created on September 21, 2016, 11:24 PM
 */

#include <iostream>
#include <string>
using namespace std;
int main()
{
   
 int i, num;
 num = 3;
 
 bool x;
 bool y ;
 
 cout <<" LOGICAL OPERATORS TRUTH TABLE"<<endl;
 cout << "X\tY\t!X\t!Y\tX&&Y\tX||Y\tX^Y\tX^Y^Y\tX^Y^X\t!(X&&Y)\tX||Y\t!(X||Y)\t!(X&&!Y)"<<endl;

// for (i = 0; i <1; i++){
     
     ((x = true) && (y = true)); {
     cout << "TRUE\tTRUE\tFALSE\tFALSE\tTRUE\tTRUE\tFALSE\tTRUE\tTRUE\tFALSE\tFALSE\tFALSE\tFALSE"<<endl;
     }
     ((x = true) && (y = false)); {
     cout << "TRUE\tFALSE\tFALSE\tTRUE\tFALSE\tTRUE\tTRUE\tTRUE\tFALSE\tTRUE\tTRUE\tFALSE\tFALSE"<<endl;
     }
     ((x = false) && (y = true)); {
     cout << "FALSE\tTRUE\tTRUE\tFALSE\tFALSE\tTRUE\tTRUE\tFALSE\tTRUE\tFALSE\tTRUE\tTRUE\tFALSE"<<endl;
     }
     ((x = false) && (y = false)); {
     cout << "FALSE\tTRUE\tTRUE\tFALSE\tFALSE\tFALSE\tFALSE\tFALSE\tFALSE\tTRUE\tTRUE\tTRUE\tTRUE"<<endl;
     }
     return 0;
}