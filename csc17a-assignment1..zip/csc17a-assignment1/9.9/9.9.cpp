/* 
 * File:   9.9.cpp
 * Author: vanessa
 *
 * Created on September 28, 2016, 5:02 PM
 */

#include <iostream>
 using namespace std;
 
 // Function prototype
 double getMedian(int *, int);
 
 int main()
 {
 	const int SIZE = 5;
 	int List[SIZE] = {1, 4, 6, 12, 17};
 	int *pList = List;
 
 	cout << "Median: " << getMedian(pList, SIZE) << endl;
 
 	return 0;
 }
 
double getMedian(int *array, int size)
 {
 	int mid = (size - 1) / 2;
 	double med;
 
 	if (size % 2 == 0)
 	{
 		med = (*(array + mid) + *(array + (mid + 1))) / 2;
 	}
 	else
 		med = *(array + mid);
 
 
 	return med;
}