/* 
 * File:   main.cpp
 * Author: vanessa
 *
 * Created on September 28, 2016, 4:48 PM
 */


 #include <iostream>
 using namespace std;
 
 // Function prototypes
 void getData(int *, int);
 void selecitonSort(int *, int);
 int getmode(int *, int);
 
 int main()
 {
 	const int ppl = 30;
 	int tickets[ppl];		

	int *btickets = tickets;
 
 	getData(btickets, ppl);
 	selecitonSort(btickets, ppl);	
 
 	for (int i = 0; i < ppl; i++)
 	{
 		cout << tickets[i] << " ";
 	}

	cout << "\nNumber of movie tickets bought by the most people: "
 		 << getmode(btickets, ppl) << endl;
 
 	return 0;
 }

 void getData(int *array, int size)
 {
 	cout << "Enter the number of movie tickets bought by each person in a year.\n";
	for (int i = 0; i < size; i++)
	{
 		cout << "Person " << (i + 1) << ": ";
 		cin  >> *(array + i);
 	}
}
// mode
 int getmode(int *array, int size)
 {
 	int count, hold, mode;
 	count = hold = 0;
 	
 	for (int index = 0; index < size; index++)
 	{
		count++;	 
 		if (*(array + index) < *(array + index + 1))
 		{
 			if(count > hold)
 			{
 				mode = *(array + index);
 				hold = count;
 			}
 			count = 0;
 		}
 	}
 	return mode;
 }
//selection sort
 void selecitonSort(int *array, int size)
 {
 	int minIndex, minValue;
 
 	for (int scan = 0; scan < (size - 1); scan++)
 	{
 		minIndex = scan;
 		minValue = *(array + scan);
 		for (int i = scan + 1; i < size; i++)
 		{
 			if (*(array + i) < minValue)
 			{
 				minValue = *(array + i);
 				minIndex = i;
 			}
 		}
 		*(array + minIndex) = *(array + scan);
 		*(array + scan) = minValue; 
 	} 
 } 