/* 
 * File:   main.cpp
 * Author: vanessa
 *
 * Created on September 28, 2016, 4:36 PM
 */

#include <iostream>
 
int main()
{
    std::cout << "Enter a positive integer: ";
    int length;
    std::cin >> length;
 
    int *array = new int[length];
 
    std::cout << "allocated an array of integers of length " << length << '\n';
 
    array[0] = 5; 
 
    delete[] array; 
    array = 0; 
 
    return 0;
}