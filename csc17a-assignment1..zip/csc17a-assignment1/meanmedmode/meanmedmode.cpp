/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   meanmedmode.cpp
 * Author: rcc
 *
 * Created on September 28, 2016, 6:46 PM
 */

#include <iostream>
#include <iomanip>
using namespace std;

// Function prototype
void getData(int *, int);
void selectionSort(int *, int);
double getAvg(int *, int);
double getMedian(int *, int);
int getMode(int *, int);

int main()
{
	int *Numbers, Num, Mode;
	double Avg, Med;

	// Ask user how many numbers.
	cout << "How many numbers do you want to enter? ";
	cin	 >> Num;

	Numbers = new int[Num];

	getData(Numbers, Num);

	selectionSort(Numbers, Num);

	Avg = getAvg(Numbers, Num);

	Med = getMedian(Numbers, Num);

	Mode = getMode(Numbers, Num);

	cout << "Statistical results for the numbers inputed:\n";
	cout << fixed << showpoint << setprecision(2);
	cout << "Average: " << Avg << endl;
	cout << "Median:  " << Med << endl;
	cout << "Mode:    " << Mode << endl;

	delete [] Numbers;
	Numbers = 0;

	return 0;
}


//getData                                     

void getData(int *array, int size)
{
	cout << "Enter numbers: \n";
	for (int i = 0; i < size; i++)
	{
		cout << " ";
		cin  >> *(array + i);
	}
}


//selectionSort                             

void selectionSort(int *array, int size)
{
	int scan, minIndex, minValue;

	for (int scan = 0; scan < (size - 1); scan++)
	{
		minIndex = scan;
		minValue = *(array + scan);
		for (int i = scan + 1; i < size; i++)
		{
			if (*(array + i) < minValue)
			{
				minValue = *(array + i);
				minIndex = i;
			}
		}
		*(array + minIndex) = *(array + scan);
		*(array + scan) = minValue;
	}
}


//getAvg                                     

double getAvg(int *array, int size)
{
	double Sum = 0;
	for (int i = 0; i < size; i++)
	{
		Sum += *(array +i);
	}
	return Sum / size;
}


//getMedian                                    

double getMedian(int *array, int size)
{
	int Mid = (size - 1) / 2;
	double Med;

	if (size % 2 == 0)
	{
		Med = (*(array + Mid) + *(array + (Mid + 1))) / 2;
	}
	else
		Med = *(array + Mid);

	return Med;
}


//getMode                                     

int getMode(int *array, int size)
{
	int Mode, Most, Count;
	Count = Most = 0;

	for (int i = 0; i < size; i++)
	{
		Count++;
		if (*(array + i) < *(array + i + 1))
		{
			if (Count > Most)
			{
				Mode = *(array + i);
				Most = Count;
			}
			Count = 0;
		}
	}
	return Mode;
}