/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   9.4.cpp
 * Author: rcc
 *
 * Created on September 28, 2016, 6:35 PM
 */

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

struct Data
{
	string Name;
	double Grade;
};

// Function prototypes
void getData(Data *, int);
void selectionSort(Data *, int);
double getAverage(Data *, int);
void displayData(Data *, int, double);

int main()
{
	Data *Test;			// To dynamically allocate an array
	double Average;		
	int Scores;			


	// Get number of scores
	cout << "How many scores do you have to average? ";
	cin  >> Scores;

	
	Test = new Data[Scores];	// Allocate memory


	getData(Test, Scores);

	selectionSort(Test, Scores);

	Average = getAverage(Test, Scores);

	displayData(Test, Scores, Average);

	delete [] Test;
	Test = 0;

	return 0;
}
 
void getData(Data *Test, int Scores)
{
	cout << "Enter the names and scores for each student.\n";
	for (int i = 0; i < Scores; i++)
	{
		cout << "Student #" << (i + 1) << endl;
		cout << "   Name: ";
		cin.ignore();
		getline(cin, (Test + i)->Name);
		do
		{
			cout << "   Score :"; 
			cin  >> (Test + i)->Grade;

			if ((Test + i)->Grade < 0)
			{
				cout << "Scores must be greater than 0.\n"
					 << "Re-enter ";
			}
			cout << endl;
		} while ((Test + i)->Grade < 0);
	}
}

void selectionSort(Data *Test, int Scores)
{
	int startscan, minIndex;
	Data *minValue;

	for (startscan = 0; startscan < (Scores - 1); startscan++)
	{
		minIndex = startscan;
		*minValue = Test[startscan];
		for (int i = startscan + 1; i < Scores; i++)
		{
			if ((Test + i)->Grade < minValue->Grade)
			{
				*minValue = Test[i];
				minIndex = i;
			}

		}
		Test[minIndex] = Test[startscan];
		Test[startscan] = * minValue;
	}
} 

//                               getAverage                                   

double getAverage(Data *Test, int Scores)
{
	double Total;

	for (int i = 0; i < Scores; i++)
	{
		Total += (Test + i)->Grade;
	}

	return Total / Scores;
} 

//                              displayData                                 

void displayData(Data *Test, int Scores, double Avg) 
{
	cout << "    Test scores\n";
	cout << "Number of scores: " << Scores << endl;
	cout << "Scores in ascending-order:\n";
	for (int i = 0; i < Scores; i++)
	{
		cout << (Test + i)->Name << ": " << (Test + i)->Grade << endl;
	}
	cout << fixed << showpoint << setprecision(2);
	cout << "Average of scores: " << Avg << endl; 
}