/* 
 * File:   4.10.cpp
 * Author: vanessa
 *
 * Created on September 21, 2016, 10:58 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main() {
    int year;
    cout << " year:";
    cin >> year;
   bool Leap year (int year);
   {if( year%100==!0) && (year%400);
    else if ( year%100== 0 && year%400);
    cout << " not a leap year" << endl;
   }
