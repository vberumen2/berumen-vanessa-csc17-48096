/* 
 * File:   4.23.cpp
 * Author: vanessa
 *
 * Created on September 21, 2016, 11:00 PM
 */

#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    
    float const PI = 3.14159;
    float radius, length, width, base, height, area;
    bool doContinue = true;
    int choice;
    bool badChoice = false;
    bool badRadius = true;
    
    

    
    do
    {
        do
        {
            badChoice = false;
            
            // Display the menu.
            cout << "\nGeometry Calculator " << endl;
            cout << "\t" << "1. Calculate the area of a circle\n" ;
            cout << "\t" << "2. Calculate the area of a Rectangle\n";
            cout << "\t" << "3. Calculate the area of a Triangle\n";
            cout << "\t" << "4. Quit\n\n";
            cout << "\t" << "Enter your choice (1-4):" << endl;
            cin >> choice;
          
            
            if (choice < 1 || choice > 4)
            {
                cout << "Error, please enter 1-4\n" << endl;
                badChoice = true;
            }
            
                
        }while( badChoice );
            
        if ( choice == 1 ) 
        {
            do
            {
                badChoice = false;
                
                cout << "Enter nonnegative value for radius: ";
                cin >> radius;
                
                if (radius < 0)
                {
                    cout << "Error: ";
                    badChoice = true;
                }
      
            }while( badChoice );
            
           area = PI * radius * radius;
           cout << "Area is " << area << endl;
            
        }
        
        if (choice==2)
        {
            do
            {
            
                badChoice = false;
                
                cout << "Enter nonnegative length and width: ";
                cin >> length >> width;
               
               if ( length < 0 || width < 0)
               {
                   cout << "Error: ";
                   badChoice = true;
               }
               
            }while( badChoice );
            
            area = length * width;
            cout << "Area is " << area << endl;
        }
        
        if (choice==3)
        {
            do
            {
                badChoice = false;
                
                cout << "Enter nonegative base and height: ";
                cin >> base >> height;
                
                
                if (base < 0 || height < 0)
                {
                    cout << "Error: ";
                    badChoice = true;
                }
                
            }while( badChoice );
            
            area = base * height * .5;
            cout << "Area is " << area << endl;
        }
        
        if ( choice==4 )
            doContinue = false;
    
    }while( doContinue );
  
    return 0;

}

