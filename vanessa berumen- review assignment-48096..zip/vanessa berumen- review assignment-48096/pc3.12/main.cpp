/* 
 * File:   main.cpp
 * Author: vanessa
 *
 * Created on September 21, 2016, 10:55 PM
 */

#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;
/*
 * 
 */
int main() {
    
    int C;
    
    cout << "whats the temperature in celcius?\t";
    cin >> C;
    double temp = ((5.0/9.0)*C)+32;
    cout << "The temperature in Farenheit is:\t" << temp << endl;
 
    return 0;
}
