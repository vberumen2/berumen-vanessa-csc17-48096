/* 
 * File:   6.7.cpp
 * Author: vanessa
 *
 * Created on September 21, 2016, 11:02 PM
 */

#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

/*
 * 
 */
int main() {
    
    int C;
    
    cout << "whats the temperature in farenheit?\t";
    cin >> C;
    double temp = ((9.0/5.0)*C)+32;
    cout << "The temperature in celcius is:\t" << temp << endl;
 
    return 0;
}

