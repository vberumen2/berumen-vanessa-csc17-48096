/* 
 * File:   3.13.cpp
 * Author: vanessa
 *
 * Created on September 21, 2016, 10:56 PM
 */

#include <iostream>
#include <iomanip>

using namespace std;

/*
 * 
 */
int main() {
    double usd; 
    double yen_dollar;
    double rand_dollar;
    double euro_dollar;
    cout << "Amount in dollars:";
    cin >> usd;
    yen_dollar = 77.620 * usd;
    rand_dollar = 8.225 * usd;
    euro_dollar =767.0 * usd;
    cout << "Amount of $$ converted:" << endl;
    cout << setprecision(2) << usd << "=" << yen_dollar << "Yen" << endl;
    cout << setprecision(2) << usd << "=" << rand_dollar << "Rand" << endl;
    cout << setprecision(2) << usd << "=" << euro_dollar << "Euro" << endl;
    return 0;
}


