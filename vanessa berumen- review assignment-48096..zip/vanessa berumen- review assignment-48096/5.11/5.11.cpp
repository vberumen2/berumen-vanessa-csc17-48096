/* 
 * File:   5.11.cpp
 * Author: vanessa
 *
 * Created on September 21, 2016, 11:01 PM
 */

#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv){
    int size;
    int days;
    float i;
    double growth;
    double results; 
    
    //Pop present
    cout<< "what is the size of the population of organisms?\n"<< endl;
        cin >> size;
    // starting number or organisms
    if(size>=2){
        // i
        cout << " what is the average population increase (as percent)?"<< endl;
        cin >> i;
        //n
        cout << "what is the number of days they will multiply?"<< endl;
        cin >> days;
       
        //  enter formula
        growth = 1 +i;
       results = size*pow(growth, days);
        // cout results
        cout << fixed << showpoint << setprecision(4);
        cout << " the size of this population of organisms is : \n";
        cout << results << endl;
        
    }else
    cout << "wrong input" << endl;//  enter formula
        // cout results;
        
return 0;
}


