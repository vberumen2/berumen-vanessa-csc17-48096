/* 
 * File:   main.cpp
 * Author: vanessa
 *
 * Created on September 21, 2016, 11:03 PM
 */

#include <iostream>
#include <string>
#include <cstdio>
using namespace std;
int main(){
const int NUM_NAMES = 20;
string names[NUM_NAMES] ={"Berumen, Vanessa", "Melendrez, Maira"
        , "Martinez, Christian", "Berumen, Gerardo","Garcia, Alan"
        , "Castro, Elvira", "Taylor, Terri", "Johnson,James"
        "Umbarger, Jeff", "Rabbit, Jessica", "Wolfe, Leonardo"
        , "Dean, James","Rodriguez, Michelle ", "Cat, Salem"
        , "Rivera, Domingo", "Ortiz, Tony","Haguewood, Ginny"
        , "Hepler, Katherine", "Clark, Amanda", "Holland, Holly"};

int i,j;
string temp;
for(i=0;i<NUM_NAMES-1;i++)
{
for(j=i+1;j<NUM_NAMES;j++)
{
if(names[i] > names[j])
{
temp = names[i];
names[i] = names[j];
names[j] = temp;
}
}
}
string place,last,first;
cout << ("Enter the last name (Warning: case sensitive): ");
cin >> last;
cout << ("Enter the first name (Warning:case sensitive) : ");
cin >> first;
place = last + ", " + first;
int low = 0, mid, high = NUM_NAMES-1;
while (low <= high)
{
mid = (low + high) / 2;
if (place < names[mid])
high = mid - 1;
else
{
if (place > names[mid])
low = mid + 1;
else
low = high + 1;
}
}
if (place == names[mid])
cout<< "Registered\n";
else
cout<< "Not found\n";
return 0;
}