/* 
 * File:   3.3.cpp
 * Author: vanessa
 *
 * Created on September 21, 2016, 10:58 PM
 */


#include <iostream>
#include <iomanip>

using namespace std;

/*
 * 
 */
int main() {
 double score1, score2, score3;
double avg;
cout << "enter score 1" << endl;
cin >> score1;
cout << "enter score 2" << endl;
cin >> score2;
cout <<"enter score 3" << endl;
cin >> score3;
avg = (score1 + score2 +score3) / 3.0;
cout << fixed << showpoint << setprecision(1);
cout << "the average is : " << avg << endl;
return 0;
}

