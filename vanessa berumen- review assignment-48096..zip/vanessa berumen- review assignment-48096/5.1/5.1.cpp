/* 
 * File:   5.1.cpp
 * Author: vanessa
 *
 * Created on September 21, 2016, 11:04 PM
 */

#include <iostream>
#include <iomanip>

using namespace std;

/*
 * 
 */
int main() 
{
    int num = 0;
    int sum = 0;
    
    
    cout << "enter how many numbers you'd like to add: \n";
    cin >> num;
            
    while ( num < 0)
    {
        cout << "enter a positive number \n";
        cin >> num;
    }
    for ( int x = 1; 1 <= num; x ++ )
    {
        sum += x;
        
    } 
    cout << "total sum is " << sum;   
    return 0;
}
